<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('admin_content'); ?>
    <h2>📊 Dashboard</h2>
    <p>Welcome to the admin dashboard. You can monitor all activity from here.</p>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('admin_scripts'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/project/Steadfast/ecommerce/resources/views/admin/pages/dashboard.blade.php ENDPATH**/ ?>