<!DOCTYPE html>
<html>
<head>
    <title><?php echo $__env->yieldContent('title', 'Time Tracker'); ?></title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
    <div class="container py-5">
        <h2 class="text-center mb-4 text-secondary">Steadfast E-Commerce</h2>
        <?php echo $__env->yieldContent('auth-content'); ?>
    </div>

    <!-- jQuery CDN -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <?php echo $__env->yieldPushContent('auth_scripts'); ?>

</body>
</html><?php /**PATH /var/www/html/project/Steadfast/ecommerce/resources/views/layouts/master.blade.php ENDPATH**/ ?>