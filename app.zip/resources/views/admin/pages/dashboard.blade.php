@extends('admin.layouts.master')

@section('title', 'Dashboard')

@section('admin_content')
    <h2>📊 Dashboard</h2>
    <p>Welcome to the admin dashboard. You can monitor all activity from here.</p>
@endsection

@push('admin_scripts')

@endpush
